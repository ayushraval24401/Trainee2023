﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //printName printnameObj = new printName();
            //printnameObj.printYourName();

            //printevennumbers evenNumberObj = new printevennumbers();
            //evenNumberObj.PrintEvenNumbers();

            //countNegElementinArray countNegNumberobj = new countNegElementinArray();
            //countNegNumberobj.CountNegValinArray();

            //printIntandString intStringObj = new printIntandString();
            //intStringObj.PrintIntandString();

            //addIntegerVal addIntegerValObj = new addIntegerVal();
            //addIntegerValObj.AddIntegerValue();

            MaxMininArray MaxMinEleObj =  new MaxMininArray();
            MaxMinEleObj.MaXMinElminArray();
        }
    }
}
