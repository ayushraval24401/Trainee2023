﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //createFile fileObj = new createFile();
            //fileObj.CreateFileAddText();

            //readFile readFileObj = new readFile();
            //readFileObj.ReadFile();

            //arrayofStringinFile arrayStringObj = new arrayofStringinFile();
            //arrayStringObj.ArrayOfString();

            //appendText appendTextObj = new appendText();
            //appendTextObj.AppendTextinFile();

            //readFirstLine readFirstLineObj = new readFirstLine();
            //readFirstLineObj.ReadFirstLineofFile();

            //cpuntLineofFile countFileLineObj = new cpuntLineofFile();
            //countFileLineObj.CountLinesofFile();

            //divideByZeroException exceptionObj = new divideByZeroException();
            //exceptionObj.DivideByZeroException();

            //simpleException simpleExceptionObj = new simpleException();
            //simpleExceptionObj.SimpleException();

            //argumentNullException argumentObj = new argumentNullException();
            //argumentObj.ArgumentNullException();

            dataMethodExtensionMethod extensionMethodObj = new dataMethodExtensionMethod();
            extensionMethodObj.DateMethodExtensionMethod();

            //emailregex emailObj = new emailregex();
            //emailObj.EncryptedDecrypted();

            //passwordEncrypt passwordObj = new passwordEncrypt();
            //passwordObj.PasswordEncrypt();
        }
    }
}
