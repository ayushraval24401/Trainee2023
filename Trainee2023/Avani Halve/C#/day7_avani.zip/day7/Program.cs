﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //integerList integerListObj = new integerList();
            //integerListObj.IntegerList();

            rangeList integerRangeObj = new rangeList();
            integerRangeObj.RangeofList();

            //sudent studentObj = new sudent();
            //studentObj.Student();
        }
    }
}
