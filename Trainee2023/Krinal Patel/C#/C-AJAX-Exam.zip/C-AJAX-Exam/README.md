# C-AJAX-Exam

Ensure the below path of JSON file.
Create a Folder named "C# AJAX Exam" and Clone the repository in it.
D:\C# AJAX Exam\Employee\Files\EmployeeData_07_04_2023.json.
